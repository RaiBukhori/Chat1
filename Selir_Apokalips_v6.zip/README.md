# Selir Apokalips — versi modular

## Menjalankan
- **Laptop:** dobel-klik `index.html`. Tidak perlu server (dicoba di Chromium).
- **`index.html` saja:** boleh dibuka sendirian, tanpa folder `games/` dan `selir/`. Markas jalan penuh. Tab **Action** tetap menampilkan tombol game, dan tiap game terbuka sebagai halaman kosong ("Belum dimuat"). Tab **Selir** terbuka dengan daftar kosong. Begitu folder `games/` dan `selir/` ditaruh di sampingnya, semuanya terisi otomatis tanpa mengubah apa pun. Selama selir belum termuat, daftar selir kosong tidak ikut disimpan, jadi save tidak rusak.
- **HP:** browser HP umumnya tidak bisa membaca file di subfolder, jadi paket modular ini dipakai di laptop.

## Struktur
```
index.html            kerangka + Markas + poster bawaan (girl/pt) + animasi kartu selir (intro) + penyambung modul (loader)
games/manifest.html   daftar game di menu Action (menu dibuat otomatis dari sini)
games/<id>/<id>.html  satu game: survive, war, misi, scavenge (dimuat saat menunya dibuka)
games/_template/      contoh game baru
selir/manifest.html   daftar selir (urutan = urutan tampil) + selir awal save baru
selir/layout.html     tampilan tab Selir: kartu poster 9:16 + bintang level (opsional; tanpa file ini tab Selir pakai daftar biasa)
selir/<nama>/         poster.html, survive.html, war.html, misi.html, scavenge.html
selir/_template/      contoh selir baru
```
Folder `core/` sudah tidak ada: isi `core/shared.html` (poster bawaan + intro) kini menyatu di `index.html`.

## Tambah selir
1. Salin `selir/_template` menjadi `selir/<nama>`.
2. Edit `poster.html` (id baru, nama, kelas, warna, `img` atau fungsi `poster(s)`), lalu file per game. Semua selir setara: tidak ada rarity.
3. Tambahkan `"<nama>"` ke `selir/manifest.html`.

Selir yang hanya punya `poster.html` tetap bisa main di semua game dengan perilaku default.
Jangan ubah `id` selir setelah ada save, dan jangan ubah key save `selir_apo1`.

## Tambah game
1. Salin `games/_template/_template.html` menjadi `games/<id>/<id>.html`, ganti `contoh` dengan `<id>`.
2. Tambahkan satu baris di `games/manifest.html`.
3. Opsional: perk selir di `selir/<nama>/<id>.html` + tambahkan `"<id>"` ke `games:[...]` di `poster.html`.

Daftar game bawaan di loader `index.html` (`DG`) hanya cadangan untuk mode `index.html` saja. Kalau `games/manifest.html` ada, dialah yang dipakai, jadi menambah game cukup lewat manifest.

## Hook per selir
| Game | Isi `APO.selirGame(id, game, {...})` |
|---|---|
| survive | `stats:{k,p,c}` (jenis skill, kekuatan, cooldown) · opsional `cast({c,s,a,p,x,hit})` |
| war | `skill:[nama,deskripsi]` · `apply(W)` (n, sh, dm, fr, zs, bl, spread, gap) |
| scavenge | `skill:[nama,deskripsi]` · `ai:{iv,d,c,...}` · `apply(P)` |
| misi | belum dipakai (kosong) |

## Tampilan Selir (`selir/layout.html`)
Tab **Selir** menampilkan kartu poster 9:16 (4 per baris, tanpa nama) dengan baris bintang di bawahnya. Ketuk kartu untuk membuka lembar detail (nama, kelas, serangan, skill) berisi tombol **Kamar**. Siluet = belum bergabung. Tidak ada mekanisme Pasukan: semua selir yang sudah bergabung ikut di Survive (War dan Scavenge punya pilihan ikut sendiri).

Bintang = level skill selir (`S.own[id].sl`, yang tampil sebagai "Lv" di Kamar):

| Level | Bintang |
|---|---|
| 1–5 | kayu, 1–5 bintang (level 1 = 1 bintang di tengah) |
| 6–10 | silver, 1–5 bintang |
| 11–15 | emas, 1–5 bintang |
| 16–20 | berlian, 1–5 bintang |
| 21–25 | gradasi ungu → biru → pink, 1–5 bintang |
| 26+ | 1 bintang bersayap (badan gradasi ungu-biru, sayap pink polos) |

- Batas level skill di game saat ini `2 + 2 × kedekatan` = 12 (lihat `upS` di `index.html`), jadi di permainan baru tampil kayu, silver, dan emas. Tier berikutnya muncul otomatis begitu batas itu dinaikkan.
- Buka `selir/layout.html` langsung di browser (dobel-klik) untuk pratinjau semua level 1–26.
- Poster: kalau `img` diisi, gambar tampil 9:16 utuh; poster vektor bawaan (2:3) dipotong tipis di kiri-kanan.
- Semua bintang SVG sederhana (satu sprite dipakai ulang). Kode desain ada di file ini saja, bukan di `index.html`; `index.html` hanya memanggil `APO.layout.sel(...)`.
- Bintang dibuat besar dan hampir menempel. Ukuran, celah antar-bintang, dan margin atas/bawah diatur lewat konstanta `SS`, `GP`, `PD` di dekat fungsi `stars` pada `selir/layout.html`. Radius sudut kartu 8px supaya bintang terluar tidak terpotong lengkung sudut di HP sempit (kalau bintang diperbesar lagi, radius ikut diperkecil).
